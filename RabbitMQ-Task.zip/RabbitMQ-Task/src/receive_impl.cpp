#include <iostream>
#include <string>
#include <thread>
#include <memory>
#include <chrono>
#include <amqpcpp.h>
#include "SimplePocoHandler.h"
#include "receive_impl.h"


ReceiverImplementation::ReceiverImplementation(std::string queueName)
    : m_queueName(queueName)
    , m_count(0)
    , m_currentCount(0)
    , m_startTime(std::chrono::steady_clock::now())
    , m_currentTime(std::chrono::steady_clock::now())
    , m_inProcess(false)
{
    std::thread t([=]() {
    	while(true) {
    	    std::this_thread::sleep_for(std::chrono::milliseconds(1000));
    	    this->reportCurrent();
    	}
    });
    t.detach();
}

void ReceiverImplementation::reportCurrent() { 
    if (!m_inProcess) {
        return;
    }
    auto diff = std::chrono::steady_clock::now() - m_currentTime;
    auto value = std::chrono::duration<double>(diff).count();
    std::cout<<"Current speed " << (int)(m_currentCount/value) <<"/sec"
	     << std::endl; 

    m_currentCount = 0;
    m_currentTime = std::chrono::steady_clock::now();
}
void ReceiverImplementation::received(const std::string& msg)
{
    if (startedMessage(msg)) {
        m_count = m_currentCount = 0;
        m_startTime = m_currentTime = std::chrono::steady_clock::now();
        m_inProcess = true;
    } else if (endingMessage(msg)) {
        m_inProcess = false;
        reportCompleteResults();  
    } else {
        ++m_count; ++m_currentCount;
    }
}
void ReceiverImplementation::reportCompleteResults() const
{
    auto diff = std::chrono::steady_clock::now() - m_startTime;
    auto value = std::chrono::duration<double>(diff).count();
    std::cout << "*******************************************" << std::endl;
    std::cout << m_count <<" messages received." << std::endl;
    std::cout << "Average speed " << (int)(m_count/value) <<"/sec"
	      << std::endl; 
    std::cout << "*******************************************" << std::endl;
    
    
}
bool ReceiverImplementation::startedMessage(const std::string& message) const
{ 
    return message == m_queueName + "_STARTED"; 
}

bool ReceiverImplementation::endingMessage(const std::string& message) const
{
    return message == m_queueName + "_ENDED"; 
}

