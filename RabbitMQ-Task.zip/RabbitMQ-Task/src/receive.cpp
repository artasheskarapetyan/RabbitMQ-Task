#include <iostream>
#include <string>
#include <thread>
#include <memory>
#include <chrono>
#include <amqpcpp.h>
#include "SimplePocoHandler.h"
#include "receive_impl.h"


class ReceiverEngine
{
public:
    ReceiverEngine(std::string queueName)
        : m_handler(new SimplePocoHandler ("localhost", 5672))
        , m_impl(queueName)
    {
        auto connection = new AMQP::Connection(m_handler, AMQP::Login("guest", "guest"), "/");
        auto channel = new AMQP::Channel(connection);
         
        auto receivedCB = std::bind(&ReceiverEngine::received, this, std::placeholders::_1, 
	         	            std::placeholders::_2, std::placeholders::_3);
        auto failCB = std::bind(&ReceiverEngine::failed, this, std::placeholders::_1);
        channel->consume(queueName, AMQP::noack).onReceived(receivedCB)
  	                                        .onError(failCB);
    }
    void loop()
    {
        m_handler->loop();
    }
private:
    void failed(const char* err) {
        m_handler->quit();
        std::cout<<"failed " << err <<"\n";
    }
    void received(const AMQP::Message &message,
                           uint64_t deliveryTag, bool redelivered) {
        m_impl.received(message.message());
    }
private:
    SimplePocoHandler * m_handler;
    ReceiverImplementation m_impl;
};



int main(int argc, char *argv[])
{
    std::string queueName = "default";
    if (argc > 1) {
        queueName = argv[1];
    }
    ReceiverEngine re(queueName);
    re.loop();
    return 0;
}
