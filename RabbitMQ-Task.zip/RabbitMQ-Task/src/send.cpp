#include <iostream>
#include <string>
#include "SimplePocoHandler.h"

class RabbitConnection
{
public:
    RabbitConnection(std::string queueName)
    : m_handler("localhost", 5672)
    , m_connection(&m_handler, AMQP::Login("guest", "guest"), "/")
    , m_channel(&m_connection)
    , m_queueName(queueName)
    {}
    void startSending(int count) {
        m_channel.onReady([&]()
        {
            if(m_handler.connected())
            {
                std::cout << "Starting Sending to " << m_queueName << std::endl;
                std::string startStr = m_queueName + "_STARTED";
                m_channel.publish("", m_queueName, startStr);
                for (int i=0; i < count; ++i) {
                    std::string msg = "Hello World ";
                    msg += std::to_string(i+1);
                    m_channel.publish("", m_queueName, msg);
              //      std::cout << " Sent '" << str <<"'" << std::endl;
                }
                std::string endStr = m_queueName + "_ENDED";
                m_channel.publish("", m_queueName, endStr);
                m_handler.quit();
		std::cout << count << " messages was sent!" << std::endl;
            }
        });
 
        m_handler.loop();
    }

private:
    SimplePocoHandler m_handler;
    AMQP::Connection m_connection;
    AMQP::Channel m_channel;
    std::string m_queueName;
};

int main(int argc, char *argv[])
{
    std::string queueName = "default";
    if (argc > 1) {
        queueName = argv[1];
    }
    RabbitConnection r(queueName);
    int count = 0;
    while (-1 != count) {
        std::cout << "Sending Message count" << std::endl;
	std::cout << "([-1]Quite, [1]100, [2]1000, [3]10000, [4]100000) [5]Custom: "; 
	std::cin >> count;
	switch (count) {
		case -1: break;
		case 1: count = 100; break;
		case 2: count = 1000; break;
		case 3: count = 10000; break;
		case 4: count = 100000; break;
		case 5: std::cout <<"Count : "; std::cin >> count; break;
		default: continue;
	}
        r.startSending(count);
    }
    return 0;
}
