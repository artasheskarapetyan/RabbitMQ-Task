#ifndef RECEIVE_IMPL_H
#define RECEIVE_IMPL_H

#include <iostream>
#include <string>
#include <thread>
#include <memory>
#include <chrono>
#include <amqpcpp.h>
#include "SimplePocoHandler.h"


class ReceiverImplementation
{
public:
    ReceiverImplementation(std::string queueName);
    void received(const std::string &message);
    void reportCurrent();

private:
    bool startedMessage(const std::string& message) const; 
    bool endingMessage(const std::string& message) const;
    void reportCompleteResults() const;

private:
    std::string m_queueName;
    unsigned int m_count;
    unsigned int m_currentCount;
    std::chrono::time_point<std::chrono::steady_clock> m_startTime;
    std::chrono::time_point<std::chrono::steady_clock> m_currentTime;
    bool m_inProcess;
};



#endif
