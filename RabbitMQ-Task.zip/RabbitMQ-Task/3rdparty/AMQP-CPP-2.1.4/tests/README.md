I'm sorry, the test case makes use of the closed source Copernica libraries. Maybe someone
is willing to provide a test case based on plain system calls?